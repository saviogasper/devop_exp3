# Application Name

**Tier:** Add corresponding tier (1-Beginner, 2-Intermediate, 3-Advanced)

Add a clear description of the application and its main features.
Answer the following questions:

-   "What is the purpose of this application?"
-   "Are there any resources needed in order to complete the project?" - If yes, be sure to add it.

## User Stories

-   [ ] User can ... first user story
-   [ ] User can ... second user story
-   [ ] User can ... third user story
-   [ ] User can ... fourth user story
-   [ ] User can ... fifth user story
-   etc...

## Bonus features

-   [ ] User can ... first bonus feature
-   [ ] User can ... second bonus feature
-   etc...

## Useful links and resources

Add useful links and resources corresponding to this project.

## Example projects

Add one or more examples of projects that have similar functionality to this application. This will act as a developer guide.
